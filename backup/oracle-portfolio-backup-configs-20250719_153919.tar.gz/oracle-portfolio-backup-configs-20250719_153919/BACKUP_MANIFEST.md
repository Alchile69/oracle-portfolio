# Oracle Portfolio - Manifeste de Backup

## Informations Générales
- **Date de création** : Sat Jul 19 15:39:19 EDT 2025
- **Type de backup** : configs
- **Version** : 0.0.0
- **Commit** : 337dadd19659278ec54a63f1b040d5d82d4c4c0f
- **Branche** : restore/elegant-full-version

## Contenu du Backup
drwxrwxr-x 2 ubuntu ubuntu   4096 Jul 19 15:39 .
drwxrwxr-x 7 ubuntu ubuntu   4096 Jul 19 15:39 ..
-rw-r--r-- 1 ubuntu ubuntu     64 Jul 19 15:39 .firebaserc
-rw-rw-r-- 1 ubuntu ubuntu    358 Jul 19 15:39 .firebaserc.development
-rw-rw-r-- 1 ubuntu ubuntu    323 Jul 19 15:39 .firebaserc.staging
-rw-r--r-- 1 ubuntu ubuntu    424 Jul 19 15:39 .gitignore
-rw-rw-r-- 1 ubuntu ubuntu      0 Jul 19 15:39 BACKUP_MANIFEST.md
-rw-r--r-- 1 ubuntu ubuntu    424 Jul 19 15:39 components.json
-rw-rw-r-- 1 ubuntu ubuntu   2616 Jul 19 15:39 environments.config.js
-rw-r--r-- 1 ubuntu ubuntu    844 Jul 19 15:39 eslint.config.js
-rw-rw-r-- 1 ubuntu ubuntu    670 Jul 19 15:39 firebase.development.json
-rw-r--r-- 1 ubuntu ubuntu    697 Jul 19 15:39 firebase.json
-rw-rw-r-- 1 ubuntu ubuntu    674 Jul 19 15:39 firebase.staging.json
-rw-r--r-- 1 ubuntu ubuntu     95 Jul 19 15:39 jsconfig.json
-rw-rw-r-- 1 ubuntu ubuntu 266325 Jul 19 15:39 package-lock.json
-rw-rw-r-- 1 ubuntu ubuntu   3283 Jul 19 15:39 package.json
-rw-r--r-- 1 ubuntu ubuntu 182534 Jul 19 15:39 pnpm-lock.yaml
-rw-r--r-- 1 ubuntu ubuntu    326 Jul 19 15:39 vite.config.js
-rw-rw-r-- 1 ubuntu ubuntu    604 Jul 19 15:39 vitest.config.js

## Environnements
- **Production** : oracle-portfolio-prod.web.app
- **Staging** : oracle-portfolio-staging.web.app
- **Development** : oracle-portfolio-dev.web.app

## Instructions de Restauration
1. Extraire le backup dans un nouveau répertoire
2. Installer les dépendances : `npm ci --legacy-peer-deps`
3. Configurer les environnements selon ENVIRONMENTS.md
4. Restaurer les configurations Firebase
5. Tester avec : `npm test`
6. Déployer avec : `./scripts/deploy.sh [environment]`

## Vérification d'Intégrité
- **Taille totale** : 504K
- **Nombre de fichiers** : 17
- **Checksum** : 08e03ef308dbae07f7ec8e1cdc71dbae

---
*Backup généré automatiquement par Oracle Portfolio Backup System*
