# oracle-portfolio
Système d'indicateurs économiques pour l'allocation de portefeuille
